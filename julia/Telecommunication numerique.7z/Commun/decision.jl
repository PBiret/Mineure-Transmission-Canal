#author : Pierre Biret, Nicolas Georgin
#derniere modification : 10-oct-2019

function decision(x)

    if x>0
        return 1
    else
        return -1

    end
end

