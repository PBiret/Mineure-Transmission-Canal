#author : Pierre Biret, Nicolas Georgin
#derniere modification : 10-oct-2019

include("../Taux_Erreurs_Canal/courbe_ideale.jl")
include("../Taux_Erreurs_Canal/courbe_ideale_simulee.jl")
